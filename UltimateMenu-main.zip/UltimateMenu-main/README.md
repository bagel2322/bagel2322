<div align="center">
  <a href="https://ghrmt.vercel.app"><img src="https://readme-typing-svg.vercel.app/?lines=Ultimate+Menu+Script;Most+Useful+Script;Written+By+L7NEG&font=Fira%20Code&size=31&center=true&width=380&height=50&duration=4000&pause=1000" alt="Readme Typing Svg Vercel Version By L7NEG"></a>
</div>

<div align="center">
  <h1><a href="https://www.unknowncheats.me/forum/grand-theft-auto-v/565688-ultimate-menu-script.html">Ultimate Menu</a></h1>
</div>

<div align="center">
  <h1><a href="https://www.unknowncheats.me/forum/grand-theft-auto-v/597103-ultimate-menu-yimmenu.html">Ultimate Menu For YimMenu</a></h1>
</div>


# How To Use Ultimate Menu Script
For every Version of the ultimate menu (Kiddion/YimMenu) there is a different use and ways to fully Run It. 

For Kiddions script is just puting the script into scripts directory, inside the Kiddions files.

For YimMenu it is actually the same way, but first before initiating the script you will need to go to Settings > Lua > Open Folder Option 

From There Go To Scripts Folder Then Paste The Ultimate Menu In There

--------------------------------------------------------------------------------------------------
<div align="center">
  <h1> New ScreenShots V2.1</h1>
</div>

[![Ultimate Menu V2.1](https://i.ibb.co/GscY7jV/Screenshot-2024-04-20-012839.png)](https://ibb.co/Rhzr2WC)
[![Ultimate Menu V2.1](https://i.ibb.co/GPJTq2q/Screenshot-2024-04-20-013110.png)](https://ibb.co/NY3SMjM)
--------------------------------------------------------------------------------------------------
<div align="center"> <h1> <details>
  <summary>Old Versions ScreenShots</summary>


[![Old Versions ScreenShots](https://i.imgur.com/M54nsX6.png)](https://i.imgur.com/M54nsX6.png)
[![Old Versions ScreenShots](https://i.imgur.com/qszJJNK.png)](https://i.imgur.com/qszJJNK.png)
[![Old Versions ScreenShots](https://i.imgur.com/A5951n9.png)](https://i.imgur.com/A5951n9.png)
[![Old Versions ScreenShots](https://i.imgur.com/Q04ceX5.png)](https://i.imgur.com/Q04ceX5.png)
[![Old Versions ScreenShots](https://i.imgur.com/J3vquqW.png)](https://i.imgur.com/J3vquqW.png)
[![Old Versions ScreenShots](https://i.imgur.com/OKD4ruV.png)](https://i.imgur.com/OKD4ruV.png)
[![Old Versions ScreenShots](https://i.imgur.com/MmRIRzW.png)](https://i.imgur.com/MmRIRzW.png)
[![Old Versions ScreenShots](https://i.imgur.com/tuVD0wg.png)](https://i.imgur.com/tuVD0wg.png)
[![Old Versions ScreenShots](https://i.imgur.com/b2erLqZ.png)](https://i.imgur.com/b2erLqZ.png)
[![Old Versions ScreenShots](https://i.imgur.com/C1nhfs6.png)](https://i.imgur.com/C1nhfs6.png)
[![Old Versions ScreenShots](https://i.imgur.com/2kNARYV.png)](https://i.imgur.com/2kNARYV.png)
[![Old Versions ScreenShots](https://i.imgur.com/vfsnLz4.png)](https://i.imgur.com/vfsnLz4.png)
[![Old Versions ScreenShots](https://i.imgur.com/5ovnXIS.png)](https://i.imgur.com/5ovnXIS.png)
[![Old Versions ScreenShots](https://i.imgur.com/HtOYaT2.png)](https://i.imgur.com/HtOYaT2.png)
[![Old Versions ScreenShots](https://i.imgur.com/wSw48p7.png)](https://i.imgur.com/wSw48p7.png)
[![Old Versions ScreenShots](https://i.imgur.com/jz13ysV.png)](https://i.imgur.com/jz13ysV.png)
[![Old Versions ScreenShots](https://i.imgur.com/NlATJNG.png)](https://i.imgur.com/NlATJNG.png)
[![Old Versions ScreenShots](https://i.imgur.com/SSf5TwH.png)](https://i.imgur.com/SSf5TwH.png)
[![Old Versions ScreenShots](https://i.imgur.com/0QDgNad.png)](https://i.imgur.com/0QDgNad.png)
[![Old Versions ScreenShots](https://i.imgur.com/oBnOqdG.png)](https://i.imgur.com/oBnOqdG.png)
[![Old Versions ScreenShots](https://i.imgur.com/gspkbJq.png)](https://i.imgur.com/gspkbJq.png)
[![Old Versions ScreenShots](https://i.imgur.com/fQnOyPM.png)](https://i.imgur.com/fQnOyPM.png)
[![Old Versions ScreenShots](https://i.imgur.com/Zfiv9po.png)](https://i.imgur.com/Zfiv9po.png)
[![Old Versions ScreenShots](https://i.imgur.com/I7QHqM8.png)](https://i.imgur.com/I7QHqM8.png)
[![Old Versions ScreenShots](https://i.imgur.com/b0JmgBF.png)](https://i.imgur.com/b0JmgBF.png)
[![Old Versions ScreenShots](https://i.imgur.com/qZpu6Uo.png)](https://i.imgur.com/qZpu6Uo.png)
[![Old Versions ScreenShots](https://i.imgur.com/EFF9efF.png)](https://i.imgur.com/EFF9efF.png)
[![Old Versions ScreenShots](https://i.imgur.com/9QRULhG.png)](https://i.imgur.com/9QRULhG.png)
[![Old Versions ScreenShots](https://i.imgur.com/bas1EOp.png)](https://i.imgur.com/bas1EOp.png)
[![Old Versions ScreenShots](https://i.imgur.com/JMkmB7X.png)](https://i.imgur.com/JMkmB7X.png)
[![Old Versions ScreenShots](https://i.imgur.com/Im3W9vf.png)](https://i.imgur.com/Im3W9vf.png)
[![Old Versions ScreenShots](https://i.imgur.com/qw4ir1P.png)](https://i.imgur.com/qw4ir1P.png)
[![Old Versions ScreenShots](https://i.imgur.com/IZmhyCp.png)](https://i.imgur.com/IZmhyCp.png)
[![Old Versions ScreenShots](https://i.imgur.com/EN7gLdh.png)](https://i.imgur.com/EN7gLdh.png)
[![Old Versions ScreenShots](https://i.imgur.com/rSPdw5D.png)](https://i.imgur.com/rSPdw5D.png)
[![Old Versions ScreenShots](https://i.imgur.com/KOF7T0I.png)](https://i.imgur.com/KOF7T0I.png)
[![Old Versions ScreenShots](https://i.imgur.com/c6XapmD.png)](https://i.imgur.com/c6XapmD.png)
[![Old Versions ScreenShots](https://i.imgur.com/YNsHiEz.png)](https://i.imgur.com/YNsHiEz.png)
[![Old Versions ScreenShots](https://i.imgur.com/D1JDwWy.png)](https://i.imgur.com/D1JDwWy.png)
[![Old Versions ScreenShots](https://i.imgur.com/uRU7pEJ.png)](https://i.imgur.com/uRU7pEJ.png)
[![Old Versions ScreenShots](https://i.imgur.com/QqqTWhV.png)](https://i.imgur.com/QqqTWhV.png)
[![Old Versions ScreenShots](https://i.imgur.com/FfeC0g0.png)](https://i.imgur.com/FfeC0g0.png)
[![Old Versions ScreenShots](https://i.imgur.com/ewUvo9k.png)](https://i.imgur.com/ewUvo9k.png)
[![Old Versions ScreenShots](https://i.imgur.com/aIR70Sq.png)](https://i.imgur.com/aIR70Sq.png)
[![Old Versions ScreenShots](https://i.imgur.com/M33uCnH.png)](https://i.imgur.com/M33uCnH.png)
[![Old Versions ScreenShots](https://i.imgur.com/wuS93Jy.png)](https://i.imgur.com/wuS93Jy.png)
[![Old Versions ScreenShots](https://i.imgur.com/IGrWFv4.png)](https://i.imgur.com/IGrWFv4.png)
[![Old Versions ScreenShots](https://i.imgur.com/Wwcu6uJ.png)](https://i.imgur.com/Wwcu6uJ.png)
[![Old Versions ScreenShots](https://i.imgur.com/Cw3lR0K.png)](https://i.imgur.com/Cw3lR0K.png)
[![Old Versions ScreenShots](https://i.imgur.com/sK8v823.png)](https://i.imgur.com/sK8v823.png)
[![Old Versions ScreenShots](https://i.imgur.com/TU2a1dL.png)](https://i.imgur.com/TU2a1dL.png)
[![Old Versions ScreenShots](https://i.imgur.com/I4BKPNx.png)](https://i.imgur.com/I4BKPNx.png)
[![Old Versions ScreenShots](https://i.imgur.com/TfUzBnL.png)](https://i.imgur.com/TfUzBnL.png)
[![Old Versions ScreenShots](https://i.imgur.com/he7jVbf.png)](https://i.imgur.com/he7jVbf.png)
[![Old Versions ScreenShots](https://i.imgur.com/2gFkwgd.png)](https://i.imgur.com/2gFkwgd.png)
[![Old Versions ScreenShots](https://i.imgur.com/0JTNdeR.png)](https://i.imgur.com/0JTNdeR.png)
[![Old Versions ScreenShots](https://i.imgur.com/ZOhngs0.png)](https://i.imgur.com/ZOhngs0.png)
[![Old Versions ScreenShots](https://i.imgur.com/JdGNN5u.png)](https://i.imgur.com/JdGNN5u.png)
[![Old Versions ScreenShots](https://i.imgur.com/g1E5tET.png)](https://i.imgur.com/g1E5tET.png)
[![Old Versions ScreenShots](https://i.imgur.com/us8pTnv.png)](https://i.imgur.com/us8pTnv.png)
[![Old Versions ScreenShots](https://i.imgur.com/UxNxSD2.png)](https://i.imgur.com/UxNxSD2.png)
[![Old Versions ScreenShots](https://i.imgur.com/dsaBz9M.png)](https://i.imgur.com/dsaBz9M.png)
[![Old Versions ScreenShots](https://i.imgur.com/ahzoYzX.png)](https://i.imgur.com/ahzoYzX.png)
[![Old Versions ScreenShots](https://i.imgur.com/AR0fcUS.png)](https://i.imgur.com/AR0fcUS.png)
[![Old Versions ScreenShots](https://i.imgur.com/4BWvVJx.png)](https://i.imgur.com/4BWvVJx.png)
[![Old Versions ScreenShots](https://i.imgur.com/M5RIvvm.png)](https://i.imgur.com/M5RIvvm.png)
[![Old Versions ScreenShots](https://i.imgur.com/weSH8H1.png)](https://i.imgur.com/weSH8H1.png)
  
</details> </h1> </div>

--------------------------------------------------------------------------------------------------
## When Your New Updates Will Be Out?
No ETA for big updates also because i don't know actually if im going to be able to continue this script (boths) because i have a life and i need to study. This is a helpfull and fun project for everyone who wants to use it, is free and you can use my script as a template.
--------------------------------------------------------------------------------------------------
## About
-  By the way to anyone who ask's about the Ultimate-Menu script, is not entire mine, there is actually in credits every single person who i taked code from and who helped me with this.
## Latest Ultimate Menu Kiddions update was on: 20/04/2024
## Latest Ultimate Menu YimMenu update was on: 19/07/2024

