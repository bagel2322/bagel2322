# Code of Conduct

Our community is welcoming to everyone, regardless of their characteristics.

As such, we expect you to treat everyone with respect and contribute to an open and welcoming community.

DO
- have empathy and be nice to others
- be respectful of differing opinions, even if you disagree
- give and accept constructive criticism

DON'T
- use offensive or derogatory language
- troll or spam
- personally attack or harass others

Repetitive violations of these guidelines might get your access to the repository restricted.


If you feel like a user is violating these guidelines or feel treated unfairly, please refrain from publicly challenging them and instead contact a Moderator on our Discord server or send an email to admin@l7neg.tk
