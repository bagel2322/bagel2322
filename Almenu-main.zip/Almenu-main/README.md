# Alestarov Menu V3
![](https://img.shields.io/badge/dynamic/json?color=ffab00&label=Online%20Version&query=%24.game.online&url=https%3A%2F%2Fraw.githubusercontent.com%2FYimMenu%2FYimMenu%2Fmaster%2Fmetadata.json&style=flat-square&labelColor=000000) ![](https://img.shields.io/badge/dynamic/json?color=ffab00&label=Game%20Build&query=%24.game.build&url=https%3A%2F%2Fraw.githubusercontent.com%2FYimMenu%2FYimMenu%2Fmaster%2Fmetadata.json&style=flat-square&labelColor=000000)

 *Code from other scripts can be used in this script. All links to scripts and copyright holders are in the section "Credits"*

 *By using my script you agree to the User Agreement*

## Yim Menu

* [Download Yim Menu](https://github.com/YimMenu/YimMenu)

## Before using the Script, watch the Video Instruction!
* [Video Instruction](https://youtu.be/uTL90ga7-DA?si=s14BaDyJc4Lrss4A)

This script was created for the Yim Menu cheat.

This cheat contains the best ways to cheat currency in GTA 5 online.

Also in this cheat there is a Stat editor for account security, and many other functions...

The script will be supplemented, about all the changes will be written here

# New
Updated CEO method, added new features to Cayo Perico Heist Editor






# User Agreement

Use agreement：

1)When editing the script, indicate the authors

2)You agree to use the script according to the instructions

3)If you use the script not according to the instructions, the author is not responsible for your account

# Instructions for AlMenu
![image](https://github.com/Alestarov/YimMenu-lua-script-Alestarov_Menu/assets/108485130/3fe3db2c-592b-4fbb-9209-e9d141ee134f)


![image](https://github.com/Alestarov/Almenu/assets/108485130/3cc25428-a7fe-4abf-aba4-31f8b99aa067)



## Almenu Interface

![image](https://github.com/Alestarov/Almenu/assets/108485130/31e2df49-f300-4a9a-ac3f-98a3e7f14d24)


## Teleport Interface

![image](https://github.com/Alestarov/YimMenu-lua-script-Alestarov_Menu/assets/108485130/114df4b5-3b18-4d79-900a-8fbe1e93fcca)


## CMM Interface

(Computers Management Menu)

![image](https://github.com/Alestarov/Almenu/assets/108485130/5854e37c-9488-4ddb-b616-ec01797a2a56)


## Money Interface

![image](https://github.com/Alestarov/YimMenu-lua-script-Alestarov_Menu/assets/108485130/1a1b47ea-1b65-4212-9b26-a1725a777f56)

 CEO
 
![image](https://github.com/Alestarov/Almenu/assets/108485130/b2cbbcf1-ef20-485d-9e61-1c617b9117bc)



 Casino
 
![Снимок экрана 2023-08-01 161835](https://github.com/YimMenu-Lua/Alestarov-Menu/assets/108485130/c5ab6734-ba05-4349-adc4-37deb316c39d)




## Heist Editor Interface

![image](https://github.com/YimMenu-Lua/Alestarov-Menu/assets/108485130/4582fd79-ba48-454f-a7c1-c637d1ff3c7b)


Cayo Perico Heist

![image](https://github.com/Alestarov/Almenu/assets/108485130/80abd0e6-6fc5-4ec5-a945-4488069e5fdd)


Fleeca Heist

![image](https://github.com/Alestarov/YimMenu-lua-script-Alestarov_Menu/assets/108485130/8ee878c3-267a-42ff-b96b-49cf032b7cb9)

## Stat Editor Interface

![image](https://github.com/Alestarov/YimMenu-lua-script-Alestarov_Menu/assets/108485130/79db794f-6938-4c8c-a0ed-98cb3bcda413)






# Credits

## 👑 Yimura 👑
(Yim Menu Cheat creator)

Cheat on GitHub:

https://github.com/YimMenu/YimMenu
## 👑 Alestarov 👑
(compiled a script)

Profile on GitHub:

https://github.com/Alestarov
## 👑sch-lda👑
(allowed to use the code from his script "SCH-LUA-YIMMENU.lua)

(The code from the script ''SCH-LUA-YIMMENU.lua'' was implemented)

Script on GitHub:

https://github.com/sch-lda/SCH-LUA-YIMMENU
## 👑 xiaoxiao921 👑
(Helped with writing code)

Profile on GitHub:

https://github.com/xiaoxiao921
## 👑 SLON 👑
(The code from the script ''YimCeo v0.5 by Slon_.lua'' was implemented)

Script on unknowncheats:

https://www.unknowncheats.me/forum/grand-theft-auto-v/591335-yimceo-ceo-crates-method-yimmenu.html



